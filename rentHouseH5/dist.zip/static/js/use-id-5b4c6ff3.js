import{aL as e}from"./index-27f572ff.js";let r=0;function u(){const n=e(),{name:t="unknown"}=(n==null?void 0:n.type)||{};return`${t}-${++r}`}export{u};
